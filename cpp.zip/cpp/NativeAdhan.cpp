#include "NativeAdhan.h"
#include "PrayerTimes.h"
#include <jsi/jsi.h>

using namespace facebook;

namespace adhan {

jsi::Value getPrayerTimes(jsi::Runtime& runtime, const jsi::Value& thisValue, const jsi::Value* arguments, size_t count) {
    if (count < 1) {
        throw jsi::JSError(runtime, "getPrayerTimes expects at least 1 argument");
    }

    auto params = arguments[0].asObject(runtime);

    auto coordinatesObj = params.getProperty(runtime, "coordinates").asObject(runtime);
    double latitude = coordinatesObj.getProperty(runtime, "latitude").asNumber();
    double longitude = coordinatesObj.getProperty(runtime, "longitude").asNumber();

    std::string dateIso = params.getProperty(runtime, "date").asString(runtime).utf8(runtime);
    std::string timezone = params.getProperty(runtime, "timezone").asString(runtime).utf8(runtime);
    std::string method = params.getProperty(runtime, "method").asString(runtime).utf8(runtime);
    std::string madhab = params.getProperty(runtime, "madhab").asString(runtime).utf8(runtime);

    auto prayerTimes = getPrayerTimesCpp(latitude, longitude, dateIso, method, timezone, madhab);

    auto result = jsi::Object(runtime);
    for (auto const& [key, val] : prayerTimes) {
        result.setProperty(runtime, jsi::String::createFromUtf8(runtime, key), jsi::String::createFromUtf8(runtime, val));
    }

    return result;
}

} // namespace adhan